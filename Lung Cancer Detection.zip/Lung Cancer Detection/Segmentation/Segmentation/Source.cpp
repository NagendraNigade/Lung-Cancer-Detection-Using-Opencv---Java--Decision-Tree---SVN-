#include "opencv2/opencv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( )
{

    Mat image;
    image= cv::imread("../Images/Test.jpg");

  
    cv::Rect rectangle(50,70,image.cols-150,image.rows-180);

    cv::Mat result; 
    cv::Mat bgModel,fgModel; 

    // GrabCut segmentation
    cv::grabCut(image,    // input image
                    result,   // segmentation result
                            rectangle,// rectangle containing foreground 
                            bgModel,fgModel, // models
                            1,        // number of iterations
                            cv::GC_INIT_WITH_RECT); // use rectangle

    cout << "Working On Segmentation" <<endl;
    // Get the pixels marked as likely foreground
    cv::compare(result,cv::GC_PR_FGD,result,cv::CMP_EQ);
    // Generate output image
    cv::Mat foreground(image.size(),CV_8UC3,cv::Scalar(255,255,255));
    image.copyTo(foreground,result); // bg pixels not copied

    // draw rectangle on original image
    cv::rectangle(image, rectangle, cv::Scalar(255,255,255),1);
    cv::namedWindow("Image");
    cv::imshow("Image",image);

    // display result
    cv::namedWindow("Segmented Image");
    cv::imshow("Segmented Image",foreground);

    waitKey();
    return 0;
}