




//..............Required Headers

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include<string>

//..............Required Namespaces

using namespace cv;
using namespace std;

//..............Matrix To Store Image Pixels..Its datatype used to store fixed size array matrix
Mat src; 
Mat src_gray; 
Mat image_roi;

int thresh = 255;
int max_thresh = 255;
int Tumor_Total=0;
int Tumor_Lessthan_25=0;
int Tumor_Greaterthen_25=0;
int Total_Tumor_Area=0;
int Total_Tumor_Length=0;
int Max_Tumor_Area=0;
RNG rng(12345);//random number generator.

//Added Later
char filename[50];
string filestring;

/// Function header
void thresh_callback(int, void* );

//..............Main Function Starts Here
int main( int argc, char** argv )
{

	//..............Load Image Pixels
	//src = imread("../Images/Normal_01.jpg");
	cout<<"Enter Image Name With Extention For Example (Normal_01.jpg) :";
	cin>>filename;
	//cout<<filename;
	filestring = "../Images/";
	filestring.append(filename);
	//cout<<filestring;
	src = imread(filestring);

	//..............Convert Image Into Gray
	cvtColor( src, src_gray, CV_BGR2GRAY );

	//..............Applying Filter it blurs the image using Normalized box filter
	blur( src_gray, src_gray, Size(3,3) );

	//..............Keeping our Focus on Lung Only 
	Rect rectangle(60,180,src_gray.cols-150,src_gray.rows-260);
	image_roi = src_gray(rectangle);

	namedWindow( "Segmentation Focus", CV_WINDOW_AUTOSIZE );
	imshow( "Segmentation Focus", image_roi );

	//..............
	char* source_window = "Source";
	namedWindow( source_window, CV_WINDOW_AUTOSIZE );
	imshow( source_window, src );
	createTrackbar( " Canny thresh:", "Source", &thresh, max_thresh, thresh_callback );
	thresh_callback( 0, 0 );
	waitKey(0);  //..............Stops the program on key press
	return(0);

}

/** @function thresh_callback */
void thresh_callback(int, void* )
{
	Mat canny_output;
	vector<vector<Point> > contours;
	vector<Vec4i> hierarchy;

	//..............Detects Edges
	//..............Canny(InputArray image, OutputArray edges, double threshold1, double threshold2, int apertureSize=3) , apertureSize � aperture size for the Sobel() operator.
	Canny( image_roi, canny_output, thresh, thresh*2, 3 );

	//Applying Canny

	


	//End Of Canny


	imshow("Segmented Lung",canny_output);

	//..............Find Contours (Tumors in our case)
	//..............findContours(InputOutputArray image, OutputArrayOfArrays contours, OutputArray hierarchy, int mode, int method, Point offset=Point())
	//..Read More Here : http://docs.opencv.org/2.4/modules/imgproc/doc/structural_analysis_and_shape_descriptors.html?highlight=findcontours#findcontours
	findContours( canny_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

	Mat drawing = Mat::zeros( canny_output.size(), CV_8UC3 );//for filling with black color i.e a black image 8-bit dip in 3 channels

	//..............Categorizing Tumors
	double  area;
	double clength;
	for(int i=0;i<contours .size();i++)
	{
		if(hierarchy[i][2]!=-1)
		{
			Tumor_Total=Tumor_Total+1;
			area=contourArea(contours[i]);
			if(area>Max_Tumor_Area)
			{
				Max_Tumor_Area=area ;
			}
			Total_Tumor_Area=Total_Tumor_Area+area;
			if(area<=35)
			{
				Tumor_Lessthan_25=Tumor_Lessthan_25+1;
			}
			else if(area>35)
			{
				Tumor_Greaterthen_25=Tumor_Greaterthen_25+1;
			}


			clength = arcLength(contours [i],true);
			Total_Tumor_Length=Total_Tumor_Length+clength;
			Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
			drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, Point() );

		}

	}


	//..............Prining On CMD
	cout <<"Total Tumor : "<<Tumor_Total<<"\n";
	cout <<"Total Tumot Area : "<<Total_Tumor_Area<<"\n";
	cout <<"Total Tumor Length : "<<Total_Tumor_Length<<"\n";
	cout <<"Tumor Area leass than 35 : "<<Tumor_Lessthan_25<<"\n";
	cout <<"Tumor Area Greater than 35 : "<<Tumor_Greaterthen_25<<"\n";
	cout <<"Maximum Tumor Area : "<<Max_Tumor_Area<<"\n";

	//-----------------Writing into Textfile (C:\Users\Nagendra\Documents\Visual Studio 2012\Projects\Segmentation\Segmentation\Tumorfile.txt)
	ofstream myfile;
	myfile.open("Tumorfile.txt");

	/*
	myfile <<"Total Tumor : "<<Tumor_Total<<"\n";
	myfile <<"Total Tumot Area : "<<Total_Tumor_Area<<"\n";
	myfile <<"Total Tumor Length : "<<Total_Tumor_Length<<"\n";
	myfile <<"Tumor Area leass than 35 : "<<Tumor_Lessthan_25<<"\n";
	myfile <<"Tumor Area Greater than 35 : "<<Tumor_Greaterthen_25<<"\n";
	myfile <<"Maximum Tumor Area : "<<Max_Tumor_Area<<"\n";
	*/

	myfile <<Tumor_Total<<"\t"<<Total_Tumor_Area<<"\t"<<Total_Tumor_Length<<"\t"<<Tumor_Lessthan_25<<"\t"<<Tumor_Greaterthen_25<<"\t"<<Max_Tumor_Area<<" ?";
	
	myfile.close();

	//..............Displaying Tumors
	namedWindow( "Tumors", CV_WINDOW_AUTOSIZE );
	imshow( "Tumors", drawing );
}  